const xapi = require('xapi');

/********************************************************
 * Author: Robert McGonigle Jr, Video Services Engineer
 *         robertmcgoniglejr@gmail.com
 * 
 * Project Lead: Enrico Conedera
 * 
 * Release: 7/1/2020
 * Last Update: 11/2/2020
 * 
 * Version: 2
 *  
 * Description:
 *    This script was designed to allow you to store information in an unused configuration asset
 *    The Asset in this Use case is "FacilityService Service 5 Name"
 *      Changes will be needed if you are using this configuration option
 * 
 *  Memblock Indexes 0 - 12 are in use for 'projUSB_Main_1-1-0' and proj and 'USB_FirstTimeSetup_1-1-0'
********************************************************/

export { stored_Information, lastStore, memBlock, getMemInformation, memChain, memoryCapacity, updateMemBlock, sleep }

var stored_Information;
var lastStore;

function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

var memBlock = [{
  "id": "First Time Setup Wizard Status",
  "value": "Incomplete",
  "index": 0
},
{
  "id": "Video Monitors",
  "value": "",
  "index": 1
},
{
  "id": "Video Output Connector 1 MonitorRole",
  "value": "",
  "index": 2
},
{
  "id": "Video Output Connector 2 MonitorRole",
  "value": "",
  "index": 3
},
{
  "id": "Video Selfview FullscreenMode",
  "value": "",
  "index": 4
},
{
  "id": "Video Selfview OnMonitorRole",
  "value": "",
  "index": 5
},
{
  "id": "Video Selfview PIPPosition",
  "value": "",
  "index": 6
},
{
  "id": "Video Selfview Mode",
  "value": "",
  "index": 7
},
{
  "id": "Audio Microphones AGC",
  "value": "",
  "index": 8
},
{
  "id": "Audio Output Line 1 Mode",
  "value": "",
  "index": 9
},
{
  "id": "Audio Output Line 1 OutputType",
  "value": "",
  "index": 10
},
{
  "id": "USB Mode",
  "value": "",
  "index": 11
},
{
  "id": "slot_12",
  "value": "",
  "index": 12
},
{
  "id": "slot_13",
  "value": "",
  "index": 13
},
{
  "id": "slot_14",
  "value": "",
  "index": 14
},
{
  "id": "slot_15",
  "value": "",
  "index": 15
},
{
  "id": "slot_16",
  "value": "",
  "index": 16
},
{
  "id": "slot_17",
  "value": "",
  "index": 17
},
{
  "id": "slot_18",
  "value": "",
  "index": 18
},
{
  "id": "slot_19",
  "value": "",
  "index": 19
}
];

function getMemInformation() {
  xapi.config.get('FacilityService Service 5 Name').then((config) => {
    stored_Information = config.split("~");
    for (let i = 0; i < memBlock.length; i++) {
      memBlock[i].value = stored_Information[i];
    }
    return;
  });
}

getMemInformation();

function memChain() {
  let memChain = '';
  for (let i = 0; i < memBlock.length; i++) {
    if (i < (memBlock.length - 1)) {
      memChain = memChain + memBlock[i].value + "~";
    } else {
      memChain = memChain + memBlock[i].value;
    }
  }
  return memChain;
}

function memoryCapacity() {
  let percentage;
  let X;
  let Y;
  xapi.config.get('FacilityService Service 5 Name').then((config) => {
    X = [(config.length) / 1024] * 100;
    Y = [Math.round(X * 100) / 100];
    percentage = Y;
    console.debug('Memory Capacity used: ' + percentage + '%');
  }).catch(e => console.error('Error'));
}

function updateMemBlock(newInfo, blockIndex) {
  getMemInformation();
  sleep(500).then(() => {
    switch (blockIndex) {
      case blockIndex:
        lastStore = memBlock[blockIndex].value;
        memBlock[blockIndex].value = newInfo;
        xapi.config.set('FacilityService Service 5 Name', memChain());
        if (lastStore !== newInfo) {
          console.debug('Memory Update ==> Block_Id: "' + memBlock[blockIndex].id + '" changed from: "' + lastStore + '" to: "' + newInfo + '.');
          memoryCapacity();
        }
        break;
    }
  });
}