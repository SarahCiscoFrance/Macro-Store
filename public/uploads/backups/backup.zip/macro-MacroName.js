

const xapi = require('xapi');

xapi.config.set("HttpClient Mode", "On");