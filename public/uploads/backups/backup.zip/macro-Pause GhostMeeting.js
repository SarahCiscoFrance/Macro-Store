import xapi from 'xapi';

let isRoomReleasePaused = false;

xapi.Command.UserInterface.Extensions.Panel.Save({
    PanelId: "room_release_btn"
}, `<Extensions>
  <Version>1.8</Version>
  <Panel>
    <Order>2</Order>
    <PanelId>room_release_btn</PanelId>
    <Type>Home</Type>
    <Icon>Power</Icon>
    <Color>#FF503C</Color>
    <Name>Pause Room Release</Name>
    <ActivityType>Custom</ActivityType>
  </Panel>
</Extensions>`);

xapi.Event.UserInterface.Extensions.Panel.Clicked
    .on(event => {
        if(event.PanelId == 'room_release_btn' && !isRoomReleasePaused){
            xapi.Command.UserInterface.Message.Prompt.Display({
                Duration: 0,
                FeedbackId: "pause_room_release",
                "Option.1": "30min",
                "Option.2": "1h",
                "Option.3": "1h30",
                "Option.4": "2h",
                Text: "Select the pause time",
                Title: "Pause Room Release"
            });
        }
        else if(event.PanelId == 'room_release_btn' && isRoomReleasePaused){
            xapi.Command.UserInterface.Message.Prompt.Display({
                Duration: 0,
                FeedbackId: "restart_room_release",
                "Option.1": "RESTART",
                Text: "Press button below",
                Title: "Restart Room Release"
            });
        }
    });


xapi.Event.UserInterface.Message.Prompt.Response.on(response => {
    if (response.FeedbackId === "pause_room_release" && !isRoomReleasePaused) {
        switch (response.OptionId) {
            case '1':
                console.log('30min');
                pauseMacro(30);
                break;
            case '2':
                console.log('1h');
                pauseMacro(60);
                break;
            case '3':
                console.log('1h30');
                pauseMacro(90);
                break;

            case '4':
                console.log('2h');
                pauseMacro(120);
                break;
            default:
                console.error(`Error, we are out of ${response.OptionId}.`);
        }
    }
    else if(response.FeedbackId === "restart_room_release"){
      isRoomReleasePaused = false;
      xapi.Command.UserInterface.Extensions.Panel.Update
    ({ Color: '#FF503C', Name: 'Pause Room Release', PanelId: 'room_release_btn'});
    }
});

function pauseMacro(amountTime){
  isRoomReleasePaused = true;
//xapi.Command.UserInterface.Extensions.Panel.Remove({ PanelId: 'room_release_btn'});
xapi.Command.UserInterface.Extensions.Panel.Update
    ({ Color: '#30D557', Name: 'Start Room Release', PanelId: 'room_release_btn'});
   /* setTimeout(function(){ 

     }, amountTime*60000);*/
}