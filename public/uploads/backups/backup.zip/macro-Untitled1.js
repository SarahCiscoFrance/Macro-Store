const xapi = require('xapi');
var alertDuration = 60;

/*xapi.Status.UserInterface.Extensions.Widget
    .get()
    .then(widgets => {
      console.log(widgets.filter(widget => widget.WidgetId == 'storeAutoButton')[0].Value);
    });*/
xapi.command("UserInterface Message Prompt Display", {
                Text: "The current booking <br> will be deleted",
                FeedbackId: 'alert_response',
                'Option.1': 'DONT DELETE !',
            })
  var refreshInterval = setInterval(updateEveryMinutes, 1000);
xapi.Command.Audio.Volume.Set({ Level: 100});
function updateEveryMinutes() {
  alertDuration = alertDuration - 1;
  if(alertDuration <=0){
    clearInterval(refreshInterval);
    xapi.Command.UserInterface.Message.TextLine.Clear({});
  }else{

xapi.command('UserInterface Message TextLine Display', {
                text: '<br>Meeting will be deleted in: ' + alertDuration + ' seconds<br>',
                duration: 0
            });
      xapi.Command.Audio.Sound.Play({ Sound: "KeyTone"})
  }

  
}
