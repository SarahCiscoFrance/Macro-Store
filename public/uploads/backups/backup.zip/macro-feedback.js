const xapi = require('xapi');

xapi.config.set("HttpClient Mode", "On");
xapi.config.set("HttpClient AllowHTTP", "True");
xapi.config.set("HttpClient AllowInsecureHTTPS", "True");

const urlServerFeedbackMeeting = `http://websrv2.ciscofrance.com:15140/api/call`;

let currentCall = {
  "codec": {},
  "callHistoryData": {}
};

xapi.status.get("Network 1").then((network) => {
  currentCall.codec.macAddress = network.Ethernet.MacAddress;
  currentCall.codec.ipAddress = network.IPv4.Address;
  
  xapi.status.get("SystemUnit").then((system) => {
    currentCall.codec.productType = system.ProductId;
    
    xapi.status.get("UserInterface ContactInfo Name").then((name) => {
      currentCall.codec.systemName = name;
      
      xapi.event.on("CallDisconnect", (event) => {
        //console.log('calldisconnect');
        if (event.Duration > 0) {
          getFeedbacks();
        }
      });
    });
  });
});

  xapi.event.on("Standby", function(event) {
    xapi.command("UserInterface Message Prompt Clear", {
      FeedbackId: "callrating"
    })
    .catch(function(error) {
      console.error(error);
    });
  });
  
    xapi.event.on("UserInterface Message Prompt Response", function(event) {
    //console.log('REPONSE !!!!')
    if (event.FeedbackId === "callrating") {
      currentCall.rate = event.OptionId;
      
      xapi.command("UserInterface Message Prompt Clear", {
        FeedbackId: "callrating"
      })
      .catch(function(error) {
        console.error(error);
      });
      
      xapi.command("UserInterface Message TextInput Display", {
        Duration: 0,
        FeedbackId: "feedbacks",
        InputType: "SingleLine",
        KeyboardState: "Open",
        Placeholder: "Ecrivez vos commentaires ici",
        SubmitText: "Envoyer",
        Text: "Vos commentaires sont très importants pour nous",
        Title: "Feedback"
      })
      .catch(function(error) {
        console.error(error);
      });
    }
  });
  
    xapi.event.on("UserInterface Message TextInput Response", function(event) {
    //console.log('REPONSE TEXT INPUT');
    if (event.FeedbackId === "feedbacks") {
      currentCall.feedbacks = event.Text;
      
       xapi.command("UserInterface Message TextInput Clear", {
        FeedbackId: "feedbacks"
      })
      .catch(function(error) {
        console.error(error);
      });
      
      xapi.command("UserInterface Message Alert Display", {
        Duration: 3,
        Text: "Merci beaucoup pour ce feedback !",
        Title: "Merci"
      })
      .catch(function(error) {
        console.error(error);
      });
      
      getCallHistory();
    }
  });

function getFeedbacks() {
  xapi.command("UserInterface Message Prompt Display", {
    Title: "Comment s'est passée la réunion ?",
    Text: "Veuillez évaluer cet appel sur une échelle de 1 à 5",
    FeedbackId: "callrating",
    "Option.1": "1",
    "Option.2": "2",
    "Option.3": "3",
    "Option.4": "4",
    "Option.5": "5",
    Duration: 0
  })
  .catch(function(error) {
    console.error(error);
  });
}

function getCallHistory() {
  getCallHistoryId((callHistoryId) => {
    getCallHistoryData(callHistoryId, (callHistoryData) => {
      currentCall.callHistoryData = callHistoryData;
      
      sendFeedbacks();
    });
  });
}

function getCallHistoryId(callback) {
  xapi.command("CallHistory Recents", {
    Limit: 1
  })
  .then(callHistory => {
    callback(callHistory.Entry[0].LastOccurrenceHistoryId);
  })
  .catch(function(error) {
    console.log("error");
    console.error(error);
  });
}

function getCallHistoryData(callHistoryId, callback) {
  xapi.command("CallHistory Get", {
    CallHistoryId: callHistoryId,
    DetailLevel: "Full"
  })
  .then(callHistoryData => {
    callback(callHistoryData);
  })
  .catch(function(error) {
    console.error(error);
  });
}

function sendFeedbacks() {
  console.log('Sending Feedbacks');
  console.log(JSON.stringify(currentCall));
  xapi.command('HttpClient Post', {
    Header: ["Content-Type: application/json"],
    AllowInsecureHTTPS: true,
    Url: urlServerFeedbackMeeting
  }, JSON.stringify(currentCall))
  .catch((err) => {
    console.log(err);
  });
}

