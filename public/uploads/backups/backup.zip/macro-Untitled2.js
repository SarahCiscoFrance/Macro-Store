import xapi from 'xapi';


var roomAnalyticsListener = xapi.Status.RoomAnalytics.on(value => console.log(value));



console.log(roomAnalyticsListener.registration);







    /*setTimeout(function(){ 
      xapi.Command.UserInterface.Extensions.Panel.Close({ }); 
    }, 3000);*/

setTimeout(function(){
    roomAnalyticsListener();
   setTimeout(function(){
   console.log(roomAnalyticsListener.registration);
   }, 3000);
   }, 3000);