/**
 * rudferna@cisco.com
 * Version: 1.0
 */

import xapi from 'xapi';

var hide_Time = 1; //<== set the number of minutes HERE /!\

var waiting_time = hide_Time * 60000;

xapi.command('UserInterface Extensions Panel Save', {
    PanelId: 'hideButton'
  },
    `
<Extensions>
  <Version>1.7</Version>
  <Panel>
    <PanelId>hideButton</PanelId>
    <Type>Home</Type>
    <Icon>Disc</Icon>
    <Name>Clean Touch10 For `+ hide_Time +` min</Name>
    <ActivityType>Custom</ActivityType>
  </Panel>
</Extensions>
`
);

xapi.event.on('UserInterface Extensions Panel Clicked', (event) => {
    if (event.PanelId !== 'hideButton') return

    xapi.command('UserInterface Extensions List', {
        ActivityType: "Custom"
    }).then((volume) => {
        removeExtensionUI(volume.Extensions.Panel);
        xapi.config.set('UserInterface Features HideAll', 'True');
        console.log("ExtensionsUI Removed !");
        setTimeout(function() {
            restoreExtensionUI(volume.Extensions.Panel, volume.Extensions.Version);
            xapi.config.set('UserInterface Features HideAll', 'False');
            console.log("ExtensionsUI Restored !")
        }, waiting_time);
    });
});

function OBJtoXML(obj) {
  var xml = '';
  for (var prop in obj) {
    xml += obj[prop] instanceof Array ? '' : "<" + prop + ">";
    if (obj[prop] instanceof Array) {
      for (var array in obj[prop]) {
        xml += "<" + prop + ">";
        xml += OBJtoXML(new Object(obj[prop][array]));
        xml += "</" + prop + ">";
      }
    } else if (typeof obj[prop] == "object") {
      xml += OBJtoXML(new Object(obj[prop]));
    } else {
      xml += obj[prop];
    }
    xml += obj[prop] instanceof Array ? '' : "</" + prop + ">";
  }
  var xml = xml.replace(/<\/?[0-9]{1,}>/g, '');
  return xml
}

function restoreExtensionUI(arrayObj, versionNumber){
  arrayObj.forEach(element => {
    xapi.command('UserInterface Extensions Panel Save', {
    PanelId: element.PanelId
  },
    `
<Extensions>
	<Panel>`
		+OBJtoXML(element)+
	`</Panel>
	<Version>`+versionNumber+`</Version>
</Extensions>
`
  );
  });
}

function removeExtensionUI(arrayObj){
  arrayObj.forEach(element => {
    xapi.command('UserInterface Extensions Panel Remove', {
    PanelId: element.PanelId
  });
  });
}