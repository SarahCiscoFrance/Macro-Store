/**
 * Author: rudferna@cisco.com
 * Version: 1.0
 * Date: 30/03/2021
 */
import xapi from 'xapi';

xapi.event.on('UserInterface Extensions Widget Action', onGui);

xapi.Command.UserInterface.Extensions.Widget.SetValue({ Value: "23°C", WidgetId: 'widget_actual_temp'});

async function onGui(event) {
  console.log(event)

  if(event.Type == 'pressed' && event.WidgetId == 'storeUpDown'){
    if(event.Value == "increment"){
      //check si relay1 bien a 0 
      if(await getStatus(1) == "0"){
        console.log("INSIDE !!")
        sendCommand(1);
      }
    }
    else{
      //check si relay2 bien a 0
      if(await getStatus(2) == "0"){
        sendCommand(2);
      }
    }
  }
  else if(event.Type == 'released' && event.WidgetId == 'storeUpDown'){
    if(event.Value == "increment"){
      if(await getStatus(1) == "1"){
        sendCommand(1);
      }
    }
    else{
      if(await getStatus(2) == "1"){
        sendCommand(2);
      }
    }
  }
  else if(event.Type == 'pressed' && event.WidgetId == 'storeFullDown'){
      if(await getStatus(2) == "0"){
        sendCommand(2);
        setTimeout(function(){ sendCommand(2); }, 20000);
      }
  }
  else if(event.Type == 'pressed' && event.WidgetId == 'storeFullUp'){
      if(await getStatus(1) == "0"){
        sendCommand(1);
        setTimeout(function(){ sendCommand(1); }, 20000);
      }
  }
}


function sendCommand(relay_num) {
  console.log('Sending command');
  xapi.command('HttpClient Get', {
    AllowInsecureHTTPS: true,
    Url: 'http://10.1.20.24:15125/setRelay/'+relay_num
  })
  .catch((err) => {
    console.log(err);
  });
}

function getStatus(relay_num) {
   return new Promise(resolve => {
          xapi.command('HttpClient Get', {
            AllowInsecureHTTPS: true,
            Url: 'http://10.1.20.24:15125/status'
          }).then(responseBody => {
              console.log(responseBody);
              console.log(JSON.parse(responseBody.Body));
              switch (relay_num) {
              case 1:
                resolve(JSON.parse(responseBody.Body).response.relay1);
              case 2:
                 resolve(JSON.parse(responseBody.Body).response.relay2);
              default:
                console.log(`number of relay must be 1 or 2`);
            }
          })
          .catch((err) => {
            console.log(err);
          });
   });
}

      xapi.event.on("CallSuccessful", (event) => {
        console.log('call');
        
      });


