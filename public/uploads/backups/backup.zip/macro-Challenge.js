import xapi from 'xapi';

xapi.status.on('RoomAnalytics PeopleCount Current', (numberofpeople) => askPerson(numberofpeople));

let asked = false;
var meetinglength = 15; // in minutes
var startTime;

xapi.Status.Bookings.Current.Id .on(currentBookingId => {
  setInterval(function() {
      roomIsUsed(currentBookingId);
    }, 60 * 2000);
});

function askPerson(numberofpeople){
  console.log(numberofpeople)
  if(numberofpeople >= 1 && !asked){
    asked = true;
     xapi.command("UserInterface Message Prompt Display", {
          Text: 'Choose a reservation period',
          FeedbackId: 'book',
          'Option.1': '15 min.',
          'Option.2': '30 min.',
          'Option.3': '1 hour',
        }).catch((error) => { console.error(error); });
  }
  else if (numberofpeople <= 0 && getPresence != "Yes"){
    /*if(getSoundLevel > 40)
    asked = false;
    setInterval(function() {
      checkPresence();
    }, 60 * 2000); */
  }
}


xapi.event.on('UserInterface Message Prompt Response', (event) => {
  switch(event.FeedbackId){
    case 'book':
      switch(event.OptionId){
        case '1':
          //console.log(15)
          booking_add(15);
          break;
        case '2':
          //console.log(30)
          booking_add(30);
          break;
        case '3':
          //console.log(60)
          booking_add(60);
          break;
        default:
          break;
      }
      break;
    case 'alert_response':
      switch(event.OptionId){
        case '1':
          //YES
          deleteBooking( getCurrentBookingId() );
          break;
        case '2':
          //NO
          booking_add(30);
          break;
        default:
          break;
      }
      break;
    default:
      break;
  }
});



function booking_add(length) {
  meetinglength = length;
  var bookings = [];
  
  xapi.command("Bookings List").then((bookings) => {
    if (bookings.ResultInfo.TotalRows <= 0) {
      startTime = new Date();
      startTime = getCiscoDeviceDateFormatFromJSDate(startTime);
      //var endtime = new Date();
      //endtime.setMinutes(endtime.getMinutes() + meetinglength);
      //endtime = getCiscoDeviceDateFormatFromJSDate(endtime);
      
      createBooking("Test", "rudferna@cisco.com", startTime, 5);
      
      //var myBookings = '<Bookings item="1" status="OK">' + getBookingsListXML() + '</Bookings>' ;
      
      

    } else {
      displayTextOnScreen("Information", "Room Already Book.");
    }
  })
}

function createBooking(bookingTitle, uriToCall, startTime, duration){
  console.log(bookingTitle, uriToCall, startTime, duration)
  xapi.command('Bookings Put', {},`{
    "Bookings": [
    {
    "Id": "6",
    "Number": `+uriToCall +`,
    "Organizer": {
    "Name": "John Doe"
    },
    "Protocol": "SIP",
    "Time": {
    "Duration": 1,
    "EndTimeBuffer": 50,
    "StartTime": `+startTime +`
    },
    "Title": `+bookingTitle +`
    }
    ]
   }`);
}


function displayTextOnScreen(title, msg) {
  xapi.command("UserInterface Message Alert Display", {
    Title: title,
    Text: msg,
    Duration: 10
  });
}

function getCiscoDeviceDateFormatFromJSDate(jsdate){
  return jsdate.toISOString(jsdate).split('.')[0]+"Z";
}

function roomIsUsed(booking_id){
  if(getPresence != 'Yes' && getSoundLevel < 40 && getPeopleCount <=0){

    displayTextOnScreen("Warning", "The current booking : " + booking_id + " will be deleted");

    xapi.command("UserInterface Message Prompt Display", {
        Text: "Delete the current booking ?",
        FeedbackId: 'alert_response',
        'Option.1': 'Yes',
        'Option.2': 'No',
    }).catch((error) => { console.error(error); });
  }
}

function getPresence(){
  xapi.Status.RoomAnalytics.PeoplePresence.get().then(value => {return value});
}

function getSoundLevel(){
  xapi.Status.RoomAnalytics.Sound.Level.A.get().then(value => {return value});
}

function getPeopleCount(){
  xapi.Status.RoomAnalytics.PeopleCount.Current .get() .then(value => {return value});
}

function getCurrentBookingId(){
  xapi.Status.Bookings.Current.Id .get() .then(value => {return value});
}

function deleteBooking(id){
  xapi.Command.Bookings.Delete ({ Id: id});
}