import xapi from 'xapi';
var alertDuration = 20;
var refreshInterval = setInterval(updateEverySecond, 1000);

        xapi.command("UserInterface Message Prompt Display", {
            Text: "This room seems unused. It will be self-released.<br>Press check-in if you have booked this room",
            FeedbackId: 'alert_response',
            'Option.1': 'CHECK IN',
        }).catch((error) => {
            console.error(error);
        });

function updateEverySecond() {
    alertDuration = alertDuration - 1;
    if (alertDuration <= 0) {
        clearInterval(refreshInterval);
        xapi.Command.UserInterface.Message.TextLine.Clear({});
    } else {
        xapi.command('UserInterface Message TextLine Display', {
            text: 'This room seems unused. It will be released in ' + alertDuration + ' seconds.<br>Use the check-in button on the touch panel if you have booked this room.',
            duration: 0
        });
        if(alertDuration%3 == 0){
          xapi.command("UserInterface Message Prompt Display", {
              Text: "This room seems unused. It will be self-released.<br>Press check-in if you have booked this room",
              FeedbackId: 'alert_response',
              'Option.1': 'CHECK IN',
          }).catch((error) => {
              console.error(error);
        });
        }
    }
}




    xapi.event.on('UserInterface Message Prompt Response', (event) => {
        switch (event.FeedbackId) {
            case 'alert_response':
                switch (event.OptionId) {
                    case '1':
                        //To stop timeout and not delete current booking even if no presence is detected
                        clearInterval(refreshInterval);
                        xapi.Command.UserInterface.Message.TextLine.Clear({});
                        break;
                    default:
                        break;
                }
                break;
            default:
                break;
        }
    });