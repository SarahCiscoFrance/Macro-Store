
import xapi from 'xapi';
 
 xapi.config.set("Standby Signage Mode", "On");
 xapi.config.set('Standby Signage InteractionMode', 'Interactive');

xapi.event.on('UserInterface Extensions Panel Clicked', (event) => {
 if (event.PanelId === 'signage') {
//xapi.config.set("Standby Signage Url", "https://cisco.cloud.appspace.com/app/pwa/?registrationmode=passive");
xapi.command('Standby Halfwake');
 }
});
