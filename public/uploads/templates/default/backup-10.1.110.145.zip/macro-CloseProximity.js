import xapi from 'xapi';



xapi.Status.RoomAnalytics.Engagement.CloseProximity
    .on(value => {
        if(value){
          xapi.config.set('Standby Signage Url', "http://websrv2.ciscofrance.com:15198/FIRE-QUEST/WRONG.PNG")
          .then(()=>{
            xapi.command('Standby Halfwake').catch((error)=>{
              console.log(error)
            })
          })
        }


    });
// turn off after system wakes up 
xapi.status.on('Standby State', (status) => {
  if(status === 'Off'){
       xapi.config.set('Standby Signage Url', "https://cisco.cloud.appspace.com/app/pwa/?registrationmode=passive");
  }
});