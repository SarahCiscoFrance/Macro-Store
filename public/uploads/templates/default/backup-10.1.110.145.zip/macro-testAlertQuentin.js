import xapi from 'xapi';

function alertDisplay() {
	xapi.command(
	  	'UserInterface Message Alert Display',
	  	{Title : 'Room Capacity Limit Reached',
	  	Text : ('test'),
	  	Duration : (3) }
	  )
}

xapi.status
    .get('RoomAnalytics PeopleCount')
    .then((count) => 
		{
			console.log('displaying')
			xapi.Command.UserInterface.Message.Alert.Display(
    	{ Duration: 5, Text: 'testtext', Title: 'testtitle' });

		}
		)

