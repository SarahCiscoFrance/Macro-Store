import xapi from 'xapi';

var value2 = 0;

xapi.Status.RoomAnalytics.Sound.Level.A
    .on(value => {
              console.log('value: ' + value);
        console.log('value2: ' + value2);
      if ((value2 != 0) && (value > value2+10)){      
        xapi.config.set('Standby Signage Url', "https://www.youtube.com/embed/18212B4yfLg?rel=0&autoplay=1;fs=0;autohide=0;hd=0").then(
         xapi.command('Standby Halfwake').catch(e => console.error('Command error')));}
        value2=value;



    });

xapi.event.on('UserInterface Extensions Panel Clicked', (event) => {
if(event.PanelId === "ALARM"){
       xapi.config.set('Standby Signage Url', "https://www.youtube.com/embed/18212B4yfLg?rel=0&autoplay=1;fs=0;autohide=0;hd=0").then(
         xapi.command('Standby Halfwake').catch(e => console.error('Command error')));
    }    
  
});