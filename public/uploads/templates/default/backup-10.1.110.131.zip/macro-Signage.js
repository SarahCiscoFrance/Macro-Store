const xapi = require('xapi');

xapi.event.on('UserInterface Extensions Panel Clicked', (event) => {
if(event.PanelId === "Signage"){
  console.log("btn clicked");
xapi.Command.Standby.Halfwake({ });
}
});

