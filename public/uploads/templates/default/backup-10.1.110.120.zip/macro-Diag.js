const xapi = require('xapi');

xapi.event.on('UserInterface Extensions Widget Action', (event) => {
    if (event.WidgetId == 'Diag') {
        if (event.Type == 'changed') {
            switch (event.Value) {
                case 'on':
                    xapi.command("Cameras SpeakerTrack Diagnostics Start");
                    xapi.command("Video Selfview Set", {
                        Mode: 'on',
                        FullScreenMode: 'on'
                    });
                    xapi.command("Video Selfview Set FullScreenMode", 'on');
                    xapi.command("UserInterface Extensions Widget SetValue", {
                        WidgetId: 'Diag',
                        Value: 'on'
                    });
                    break;
                case 'off':
                    xapi.command("Cameras SpeakerTrack Diagnostics Stop");
                    xapi.command("Video Selfview Set", {
                        Mode: 'off',
                        FullScreenMode: 'off'
                    });
                    xapi.command("Video Selfview Set FullScreenMode", 'off');
                    xapi.command("UserInterface Extensions Widget SetValue", {
                        WidgetId: 'Diag',
                        Value: 'off'
                    });
                    break;
            }
        }
    }
});