const xapi = require('xapi');

xapi.event.on('UserInterface Extensions Widget Action', (event) => {
  if (event.Type === "clicked") {
    console.log(event.WidgetId)
    switch (event.WidgetId) {
      case 'halfwake':
        xapi.command('Standby halfwake');
         break;
      default:
        break;
    }
  }
});