const xapi = require('xapi');

//Define max ultrasound volume and current audio volume 
const maxUltVol = 90;
let curUltVol;

//Expected GUI values (In-Room Control)
const guiValues = {
  'mode'        : 'toggle_proximity-mode',
  'toclients'   : 'toggle_proximity-services-contentshare-toclients',
  'fromclients' : 'toggle_proximity-services-contentshare-fromclients',
  'callcontrol' : 'toggle_proximity-services-callcontrol',
  'audioSpinner': 'spinner_audio-ultrasound-maxvolume',
  'audioSlider' : 'slider_audio-ultrasound-maxvolume'
};

//Log function
function log(value) {
    console.log(value);
}

//Converts GUI "On"/"Off" values to "Enabled"/"Disabled" and vice versa for the Proximity services. 
function convertToggle(value, gui=true) {
  if (gui) {
    return (value == 'Enabled') ? 'on':'off';
  } 
  return (value == 'on') ? 'Enabled':'Disabled';
}

//Convert slider values to reflect ultrasound setting value  and vice versa
function convertSlider(value, gui=true) {
  return (gui) ? (value *  255 / maxUltVol).toFixed() : (value * maxUltVol / 255).toFixed();
}

//Increment or decrement the spinner value
function intCrementor(type, value) {
  if (type == 'increment') {
    if (value < maxUltVol) value++;
  } else {
    if (value > 0) value--;
  }
  return value;
}

//Set gui value and log event
function setGUIValue(guiId, value) {
  xapi.command('UserInterface Extensions Widget SetValue', { 
      WidgetId: guiId, 
      Value: value
  });
  log('[GUI]: ' + guiId + ' : ' + value);
}

//Set the configuration in the xAPI
function setAPIValue(param, value) {
   xapi.config.set(param, value)
    .catch((error) => {
      log(JSON.stringify(error));
   });
   log('[API]: ' + param + ' : ' + value);
}

//Listen for API changes and set the GUI values when changed
function listenAPI() {
    xapi.config.on('Proximity Mode', configValue => { 
        setGUIValue(guiValues.mode, configValue.toLowerCase()); 
    });
    
    xapi.config.on('Proximity Services ContentShare ToClients', configValue => { 
        setGUIValue(guiValues.toclients, convertToggle(configValue)); 
    });
    
    xapi.config.on('Proximity Services ContentShare FromClients', configValue => { 
        setGUIValue(guiValues.fromclients, convertToggle(configValue));
    });
    
    xapi.config.on('Proximity Services CallControl', configValue => { 
        setGUIValue(guiValues.callcontrol, convertToggle(configValue)); 
    });
    
    xapi.config.on('Audio Ultrasound', configValue => {
        setGUIValue(guiValues.audioSlider, convertSlider(configValue.MaxVolume)); 
        setGUIValue(guiValues.audioSpinner, configValue.MaxVolume);
        curUltVol = parseInt(configValue.MaxVolume);
    });
    
    xapi.event.on('UserInterface Extensions Widget Action', e => {
        const parts = e.WidgetId.split('_');
        const params = parts[1].split('-').join(' ');
        
        if (parts[0] === 'spinner' && e.Type === 'clicked') 
          setAPIValue(params, intCrementor(e.Value, curUltVol));
          
        if (parts[0] === 'toggle') {
          let val = e.Value;
          if (!params.includes('mode')) {
            val = convertToggle(val, false);
          }
          setAPIValue(params, val);
        }
        
        if (parts[0] === 'slider' && e.Type == 'released')
          setAPIValue(params, convertSlider(e.Value, false));
    });
}

//Run on macro start or boot to sync GUI values to API values
function setInitialValues() {
  xapi.config.get('Proximity Mode').then((currentValue) => { 
    setGUIValue(guiValues.mode, currentValue.toLowerCase());
  });
    
  xapi.config.get('Audio Ultrasound').then((currentValue) => {
    setGUIValue(guiValues.audioSpinner, currentValue.MaxVolume);
    setGUIValue(guiValues.audioSlider, convertSlider(currentValue.MaxVolume, 'slider'));
    curUltVol = parseInt(currentValue.MaxVolume);
  });
    
  xapi.config.get('Proximity Services').then((currentValue) => {
    setGUIValue(guiValues.toclients, convertToggle(currentValue.ContentShare.ToClients)); 
    setGUIValue(guiValues.fromclients, convertToggle(currentValue.ContentShare.FromClients));
    setGUIValue(guiValues.callcontrol, convertToggle(currentValue.CallControl));
  });
} 
//Init
setInitialValues();

//Start listner
listenAPI();

//Author: Magnus Ohm