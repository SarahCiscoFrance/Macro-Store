const xapi = require('xapi');

xapi.config.set("HttpClient Mode", "On");
xapi.config.set("HttpClient AllowHTTP", "True");
xapi.config.set("HttpClient AllowInsecureHTTPS", "True");
xapi.config.set("RoomAnalytics PeopleCountOutOfCall", "On");
xapi.config.set("RoomAnalytics PeoplePresenceDetector", "On");
xapi.config.set("RoomAnalytics AmbientNoiseEstimation Mode", "On");
xapi.config.set("Proximity Mode", "On");
xapi.config.set("Standby WakeupOnMotionDetection", "On");

const urlServerPeoplePresence = `http://10.1.20.24:15133/codec/room-analytics`;


xapi.status.on("RoomAnalytics", (roomAnalytics) => {
  let data = {
    "Status": {
      "Identification": {
        "MACAddress": {
          
        },
        "ProductID": {
          
        }
      },
      "RoomAnalytics": roomAnalytics,
      "PeripheralsRoomAnalytics": {}
    }
  };
  
  xapi.status.get("Network 1 Ethernet MacAddress").then((macAddress) => {
    data.Status.Identification.MACAddress.Value = macAddress;
    
    xapi.status.get("SystemUnit ProductId").then((productId) => {
      data.Status.Identification.ProductID.Value = productId;
      console.log(roomAnalytics);
      xapi.command('HttpClient Post', { 
        Header: ["Content-Type: application/json"],
        AllowInsecureHTTPS: true,
        Url: urlServerPeoplePresence
      }, JSON.stringify(data))
      .catch((err) => {
        console.log(err);
      });
    });
  });
});