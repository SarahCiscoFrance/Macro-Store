const xapi = require('xapi');

xapi.event.on('UserInterface Extensions Panel Clicked', (event) => {
if(event.PanelId === "Signage"){
xapi.Command.Standby.Halfwake({ });
}
});