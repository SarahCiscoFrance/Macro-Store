import xapi from 'xapi';

xapi.event.on('UserInterface Extensions Panel Clicked', (event) => {
 if (event.PanelId === 'panel_3') {
xapi.Command.Dial({ Number: 'demofr@m.webex.com' });
 }
});