var memory = {
    "./_$Info": {
        "Warning": "Do NOT modify this document, as other Scripts/Macros may rely on this information",
        "AvailableFunctions": {
            "local": [
                "mem.read('key')",
                "mem.write('key', 'value')",
                "mem.remove('key')",
                "mem.print()"
            ],
            "global": [
                "mem.read.global('key')",
                "mem.write.global('key', 'value')",
                "mem.remove.global('key')",
                "mem.print.global()"
            ]
        },
        "Guide": "https://github.com/Bobby-McGonigle/Cisco-RoomDevice-Macro-Projects-Examples/tree/master/Macro%20Memory%20Storage"
    },
    "ExampleKey": "Example Value",
    "USB_Mode_Version_2": {
        "usbMode_Status": {
            "state": false,
            "fts": false
        },
        "usbMode_Defaults": {
            "info": {
                "platform": "Room Kit",
                "compatibilityLevel": "plus"
            },
            "defaults": {
                "info": "defaults collected every time USB mode is enabled. The \"saved_Defaults\" the most recent defaults found for USB mode.",
                "saved_Defaults": {
                    "monitor_Role": {
                        "conx_1": "First",
                        "conx_2": "First"
                    },
                    "hzOffset_1": "0",
                    "audioMic_AGC": "On",
                    "audioOut_1": {
                        "mode": "On",
                        "outputType": "Loudspeaker"
                    },
                    "hzOffset_2": "0",
                    "video_Monitors": "Single",
                    "selfView": {
                        "fullscreenMode": "Off",
                        "onMonitorRole": "First",
                        "pipPosition": "CenterRight",
                        "mode": "On"
                    }
                }
            }
        }
    }
}