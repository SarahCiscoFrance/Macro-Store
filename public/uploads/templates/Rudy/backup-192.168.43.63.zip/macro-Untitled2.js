const xapi = require('xapi');

let bookingId;

function askConfirmation() {
//check with user for confirmation
xapi.Command.UserInterface.Message.Prompt.Display({
    Title: 'Booking Deletion Confirmation',
    Text: 'Are you sure you want to Clear the Booking ?',
    FeedbackId: 'option',
   'Option.1' : 'Yes',
   'Option.2' : 'No',
  });

xapi.Event.UserInterface.Message.Prompt.Response.on((event) => {
  if (event.FeedbackId === 'option') {
    if (event.OptionId === '1')
  {
    clearbooking();
    console.log('Cleared Booking');
  }
  else if(event.OptionId === '2') {
    xapi.Command.UserInterface.Message.TextLine.Display({
      Text: "Booking not Cleared" ,
      Duration: 5,
    });
    console.log('Retain Booking');
    }

  }
});
}

async function clearbooking() 
{
  bookingId = await xapi.Status.Bookings.Current.Id.get()
xapi.Command.Bookings.Get({
                 Id: bookingId
             }).then(book => {
                 xapi.Command.Bookings.Respond({
                     Type: "Decline",
                     MeetingId: book.Booking.MeetingId
                 });
             });
}

async function listenToGui() {
	// If the user interfaction event triggers we will listed to it and perform the following code
	// All the informarion about the event is passed in the "event" object
	xapi.event.on('UserInterface Extensions Panel Clicked', (event) => {

		// On clicking the Panel for Clear Booking
		if (event.PanelId === 'clear_booking') {
      askConfirmation();
		}
	});
}

listenToGui();