import xapi from 'xapi';//test macro-store

function go(){
            xapi.Command.Bookings.Get({
                Id: "webex-5"
            }).then(book => {
              console.log(book)
                xapi.Command.Bookings.Respond({
                    Type: "Decline",
                    MeetingId: book.Booking.MeetingId
                });
            });
}

go()
