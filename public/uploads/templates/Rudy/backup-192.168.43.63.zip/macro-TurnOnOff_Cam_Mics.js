import xapi from 'xapi';

var status

xapi.Command.UserInterface.Extensions.Set(
  { ConfigId: 'default' },
  `
<Extensions>
  <Version>1.8</Version>
  <Panel>
    <Order>1</Order>
    <PanelId>mute_btn</PanelId>
    <Type>Home</Type>
    <Icon>Power</Icon>
    <Color>#FC5143</Color>
    <Name>On/Off Camera Micro</Name>
    <ActivityType>Custom</ActivityType>
  </Panel>
</Extensions>
`,
);



xapi.Event.UserInterface.Extensions.on(async event => {
status = await xapi.Status.Video.Input.MainVideoMute.get()

console.log(status)
    if(event.Panel.Clicked.PanelId === "mute_btn"){
      if(status === "Off"){
        xapi.Command.Audio.Microphones.Mute();
        xapi.Command.Video.Input.MainVideo.Mute();
      }
      else{
        xapi.Command.Audio.Microphones.Unmute();
        xapi.Command.Video.Input.MainVideo.Unmute();
      }

    }
});