import xapi from 'xapi';

xapi.Config.Standby.Signage.Mode.set('On');
xapi.Config.Standby.Signage.Mode.set('On');

xapi.Event.UserInterface.Assistant.Notification.on(async (event) => {
  const { Name } =  event;
  if(Name === "Room_Metric"){
    //const mac = await xapi.Status.Network[1].Ethernet.MacAddress.get()
    const mac = "00:A5:BF:C4:3E:E5"
    //xapi.Config.Standby.Signage.Url.set(`http://websrv2.ciscofrance.com:15152/${mac}`);
    //xapi.Command.Standby.Halfwake();
    xapi.Command.UserInterface.WebView.Display(
    { Title: 'Données Environnmentales de la Salle', Url: `http://websrv2.ciscofrance.com:15152/${mac}` });
  }

});